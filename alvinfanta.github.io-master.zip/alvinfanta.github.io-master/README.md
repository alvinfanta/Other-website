This is my portofolio type thingy website! It's open source so if you guys want to make some what same website like me, you can use this!
Try not to copy almost everything and only change the text.

-Alvin
